from tkinter import *
from tkinter import messagebox
import customtkinter as cus
from tkinter import ttk
import tkinter as tk

window = tk.Tk()
window.title("Nextdate")
window.geometry("400x420")
window.configure(bg="gray")

cus.CTkLabel(window, text="NEXT DATE", bg_color="gray", font=("",25) ,text_color="white").grid(row=0,column=1,pady=10)

#entry
cus.CTkLabel(window, text="Month", bg_color="gray",font=("",15)).grid(row=1,column=0,padx=20,sticky="nsew")
in_month = cus.CTkEntry(window, width=150, border_color="gray",placeholder_text="January-December")
in_month.grid(row=1,column=1,pady=5,sticky="nsew")

cus.CTkLabel(window, text="Day", bg_color="gray",font=("",15)).grid(row=2,column=0,padx=20)
in_day = cus.CTkEntry(window, width=150, border_color="gray",placeholder_text="1-31")
in_day.grid(row=2,column=1,pady=5,sticky="nsew")


cus.CTkLabel(window, text="Year", bg_color="gray",font=("",15)).grid(row=3,column=0,padx=20)
in_year = cus.CTkEntry(window, width=150, border_color="gray",placeholder_text="1812-2012")
in_year.grid(row=3,column=1,pady=5,sticky="nsew")

table = ttk.Treeview(window, columns= ("date","nextdate"), show ='headings',selectmode='browse')
vsb = ttk.Scrollbar(window, orient="vertical", command=table.yview)
vsb.grid(row=4,column=2,sticky="nse",pady=10)

table.configure(yscrollcommand=vsb.set)
table.heading("date",text= "DATE")
table.column("date",width=175,anchor=CENTER)
table.heading("nextdate",text= "NEXT DATE")
table.column("nextdate",width=180,anchor=CENTER)

table.grid(row=4,column=0,columnspan=3,pady=10,sticky="nsew")

#reset to default
def reset():
    for item in table.get_children():
      table.delete(item)
    
#nextdate
def next():
    mall=["January","Febuary","March","April","May","June","July","August","September","October","November","December"]
    m31=["January","March","May","July","August","October","December"]
    m30=["April","June","September","November"]    
    try:
        month=str(in_month.get())
        day=int(in_day.get())
        year=int(in_year.get())
            
        if (type(month) == str and type(day) == int and type(year) == int):
            showmonth = int(mall.index("%s"%(month)))
            if(year<1812 or year>2012):
                messagebox.showwarning("Alert","Year must between 1812-2012")
            
            elif(mall.count(month)==0):
                messagebox.showwarning("Alert","You must type month like\"January\"")
                
            elif(m31.count(month)>0):
                if(day<1 or day>31):
                    messagebox.showwarning("Alert","Day out of range")
                elif(day==31 and showmonth==11):
                    showday = 1
                    showmonth = 0
                    showyear = year +1
                elif(day==31):
                    showday = 1
                    showmonth = showmonth+1
                    showyear = year
                else:
                    showday = day+1
                    showmonth = showmonth
                    showyear = year
            
            elif(m30.count(month)>0):
                if(day<1 or day>30):
                    messagebox.showwarning("Alert","Day out of range")
                elif(day==30):
                    showday = 1
                    showmonth = showmonth+1
                    showyear = year
                else:
                    showday = day+1
                    showmonth = showmonth
                    showyear = year
            
            elif(int(mall.index("%s"%(month)))==1):
                if(year%4==0):
                    if(day<1 or day>29):
                        messagebox.showwarning("Alert","Day out of range")
                    elif(day==29):
                        showday = 1
                        showmonth = showmonth+1
                        showyear = year
                    else:
                        showday = day+1
                        showmonth = showmonth
                        showyear = year
                else:
                    if(day<1 or day>28):
                        messagebox.showwarning("Alert","Day out of range")
                    elif(day==28):
                        showday = 1
                        showmonth = showmonth+1
                        showyear = year
                    else:
                        showday = day+1
                        showmonth = showmonth
                        showyear = year
                
            showmonth = str(mall[showmonth])
            messagebox.showinfo("Next Date","%s %d, %d"%(showmonth,showday,showyear))
            table.insert(parent = '',index = tk.END ,values = ("%s %d, %d"%(month,day,year),"%s %d, %d"%(showmonth,showday,showyear)))
                
            in_month.delete(0,END)
            in_day.delete(0,END)
            in_year.delete(0,END)      
                
    except ValueError :
        
        month=(in_month.get())
        day=(in_day.get())
        year=(in_year.get())
        
        if (month == "" or day == "" or year == ""):   
            messagebox.showwarning("Alert","Not null !!!")

        else :
            messagebox.showwarning("Alert","Invalid!!!")
            window.destroy()     

#button        
cus.CTkButton(window, text="Next Date",width=80, fg_color="white",hover_color="white", text_color="black",command=next).grid(row=1,column=2)
cus.CTkButton(window, text="Reset",width=80, fg_color="white",hover_color="white", text_color="black",command=reset).grid(row=2,column=2)

window.grid_rowconfigure(0, weight=1)
window.grid_rowconfigure(1, weight=1)
window.grid_rowconfigure(2, weight=1)
window.grid_rowconfigure(3, weight=1)
window.grid_rowconfigure(4, weight=1)
window.grid_columnconfigure(0, weight=1)
window.grid_columnconfigure(1, weight=1)
window.grid_columnconfigure(2, weight=1)


window.mainloop()