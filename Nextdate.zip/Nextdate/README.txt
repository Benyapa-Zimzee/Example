Nextdate program 

The program can : 
1.Get date month and year and return next date in messagebox form.
2.Store next date in table.
3.Window can be scaled to the size of the screen.

What I learned :
1.Use array to create set of month for check if it 30 or 31 days
2.Create responsive widget.
3.Store value and show in table.
4.Show warnning messagebox if user input incorrect value
